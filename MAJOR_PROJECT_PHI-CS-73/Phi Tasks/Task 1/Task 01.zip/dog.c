#include <stdlib.h> 
#include <stdio.h> 
#include <string.h> 
#include "dog.h"

static void _dog_speak(const struct dog *const d)
{
	(void)d;
	puts("Woof!.");
}

struct dog *dog_new(const float age)
{
	struct dog *d = calloc(1, sizeof *d);
	if( d != NULL ){
		d = dog_create(age);
	}
	return d;
}

struct dog *dog_create(const float age)
{
	struct dog *d;
	d->age = age;
	d->vspeak = &_dog_speak;
	return d;
}

void dog_del(struct dog *const d)
{
	if( d==NULL ){
		return;
	}
	else{
		memset(d, 0, sizeof *d);
		free(d);
	}
}

void dog_cleanup(struct dog **d_ref)
{
	if( d_ref==NULL || *d_ref==NULL ){ 
		return;
	}
 	else{
		dog_del(*d_ref), *d_ref = NULL;
	}
}

void dog_speak(const struct dog *const d)
{
	if( d==NULL ){
		return;	
	}
	else{
		(*d->vspeak)(d);
	}
}

float dog_get_age(const struct dog *const d)
{
	return d != NULL ? d->age : 0.f;
}

void dog_set_age(struct dog *const d, const float age)
{
	if( d==NULL ){
		return;
	}
	else{
		d->age = age;
	}
}