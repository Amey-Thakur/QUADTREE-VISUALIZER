#ifndef DOG_H
#define DOG_H

struct dog;
typedef void speakfunc_t(const struct dog *d);

typedef struct dog{

	speakfunc_t *vspeak;
	float age;

}dog_t;

struct dog *dog_new(float age);
struct dog *dog_create(float age);

void dog_del(struct dog *d);
void dog_cleanup(struct dog **d_ref);

void dog_speak(const struct dog *d);

float dog_get_age(const struct dog *d);

void dog_set_age(struct dog *d, float age);

#endif