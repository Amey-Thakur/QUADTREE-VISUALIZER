#include <iostream>
#include <cstdlib>
#include "tinyxml2.h"


using namespace std;
using namespace tinyxml2;


void get_Data() {
	//load doc file 
	XMLDocument doc;
	const char* file = "student.xml";

	if (!doc.LoadFile(file)) {
		//get root element
		XMLElement* root_element = doc.RootElement();
		//check if root element is null or not
		if (root_element != NULL)
		{
			XMLElement* eStudents = root_element->FirstChildElement("Students"); //Students element
			//check if Students element is null or not
			if (eStudents != NULL) {
				XMLElement* student = eStudents->FirstChildElement("Student"); //Student element
				//check if Student element is null or not
				if (student != NULL) {
					//loop through every element in student
					for (; student != NULL; student = student->NextSiblingElement())
					{
						cout << "Roll No: " << student->FirstChildElement("RollNo")->GetText() << endl;
						cout << "Name: " << student->FirstChildElement("Name")->GetText() << endl;
						cout << "ID Number: " << student->FirstChildElement("IDNumber")->GetText() << endl;
						cout << "Date of Birth: " << student->FirstChildElement("DOB")->GetText() << endl;
					}

				}
				else
				{
					cout << "NULL VALUE" << endl;
				}
			}
			else
			{
				cout << "NULL VALUE" << endl;
			}
		}
		else
		{
			cout << "EMPTY FILE" << endl;
		}
	}
	else
	{
		cout << "Could not parse file" << endl;
	}
}


void update_file() {
	XMLDocument doc;
	const char* file = "student.xml";

	// Load the XML file into the Doc instance
	doc.LoadFile("student.xml");
	//Get root Element
	XMLElement* root_element = doc.RootElement();
	// Get 'file' Child
	XMLElement* eStudents = root_element->FirstChildElement("Students");
	//Create new Element
	XMLNode* student = doc.NewElement("Student");
	//Insert new Element
	eStudents->InsertEndChild(student);
	//Create new Element
	XMLElement* pElement = doc.NewElement("RollNo");
	// Set new Element Text
	pElement->SetText("58"); // RollNo
	// Insert new Element
	student->InsertEndChild(pElement);
	//Create new Element
	pElement = doc.NewElement("Name");
	// Set new Element Text
	pElement->SetText("Mega Modha"); // Name
	// Insert new Element
	student->InsertEndChild(pElement);
	// Create new Element
	pElement = doc.NewElement("IDNumber");
	// Set new element Text
	pElement->SetText("TU3F1819139"); // IDNumber
	// Insert new Element
	student->InsertEndChild(pElement);
	// Create new Element
	pElement = doc.NewElement("DOB");
	// Set new Element Text
	pElement->SetText("12/08/1999"); // DOB
	// Insert new Element
	student->InsertEndChild(pElement);

	//Save the changes into the XML file
	doc.SaveFile("student.xml");

}


int main(){

	get_Data();//get the date from xml file
	
	update_file(); //update xml file
	
	get_Data();//read updated file
	
	return 0;
}

