#include <api.h>
#include <defs.h>
#include <assert.h>

#ifdef NDEBUG
#undef NDEBUG
#endif // NDEBUG

void test_matrix_new_delete();
void test_matrix_getRowCount();
void test_matrix_getRowCount();

int main() {

	test_matrix_new_delete();
	test_matrix_getRowCount();
	test_matrix_getRowCount();

	int data[3][3] = { {1, 2, 3},
						{4, 5, 6},
						{7, 8, 9}
	};

	int(*dataptr)[3][3] = &data;
	matrix_t* mat = matrix_new(3, 3, *dataptr, NULL);

	int rows = matrix_getRowCount(mat);
	int columns = matrix_getColumnCount(mat);
	printf("Rows : %d\n\nColumns : %d\n\n", rows, columns);

	matrix_getData(mat);

	bool flag = matrix_IsSquare(mat);
	if (flag == true)
	{
		printf("Is Square \n");
	}
	else
	{
		printf("Isn't Square \n");
	}
	matrix_delete(mat);

	return 0;
}

void test_matrix_new_delete() {

 	int data[3][3] = { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} };
	int(*dataptr)[3][3] = &data;

	matrix_t* mat = matrix_new(0, 0, *dataptr, NULL);
	assert(mat == NULL);

	mat = matrix_new(-1, 0, *dataptr, NULL);
	assert(mat == NULL);

	status_t error = MATRIX_STATUS_ERROR;
	mat = matrix_new(3, 3, *dataptr, &error);
	assert(mat != NULL);
	assert(error == MATRIX_STATUS_OK);

	error = matrix_delete(NULL);
	assert(error == MATRIX_STATUS_ERROR_INVALID_ARGUMENT);
	error = matrix_delete(mat);
	assert(error == MATRIX_STATUS_OK);

}

void test_matrix_getRowCount() {

	int data[3][3] = { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} };
	int(*dataptr)[3][3] = &data;
	
	matrix_t* mat = matrix_new(3, 3, *dataptr, NULL);
	assert(mat != NULL);
	assert(3 == matrix_getRowCount(mat));
	
	matrix_delete(mat);

}

void test_matrix_getColumnCount() {

	int data[3][3] = { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} };
	int(*dataptr)[3][3] = &data;
	
	matrix_t* mat = matrix_new(3, 3, *dataptr, NULL);
	assert(mat != NULL);
	assert(3 == matrix_getColumnCount(mat));
	
	matrix_delete(mat);
}