#ifndef __PCF_GRAPHICS_MATRIX_TYPES_H_INCLUDED__
#define __PCF_GRAPHICS_MATRIX_TYPES_H_INCLUDED__

#include <pcf/graphics/types.h>

PCF_GRAPHICS_BEGIN_CDECLARE

typedef void GraphicsMatrix_t;

typedef enum
{
  enGraphicsMatrixOperationOrder_Prepend,
  enGraphicsMatrixOperationOrder_Append
}EnGraphicsMatrixOperationOrder_t;

PCF_GRAPHICS_END_CDECLARE

#endif // __PCF_GRAPHICS_MATRIX_TYPES_H_INCLUDED__
