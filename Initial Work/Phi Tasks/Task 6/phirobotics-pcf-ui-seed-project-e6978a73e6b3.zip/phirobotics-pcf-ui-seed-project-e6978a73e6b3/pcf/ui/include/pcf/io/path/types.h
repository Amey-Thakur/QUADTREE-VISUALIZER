#ifndef __PCF_IO_PATH_TYPES_H_INCLUDED__
#define __PCF_IO_PATH_TYPES_H_INCLUDED__

#include <pcf/io/path/defs.h>
#include <pcf/io/types.h>

#endif // __PCF_IO_PATH_TYPES_H_INCLUDED__
