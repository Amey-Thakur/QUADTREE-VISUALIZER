#include <api.h> // for the matrix functions
#include <stdlib.h> // for malloc and free
#include <defs.h> // for status codes
#include <stdio.h> // 

struct matrix {
	int rows;
	int columns;
	int* data;
};

matrix_t* matrix_new(int rows, int columns, int* dataptr, status_t* error) {
	status_t status = MATRIX_STATUS_OK;
	matrix_t* result = NULL;
	if (rows < 1 || columns < 1)
	{
		status = MATRIX_STATUS_ERROR_INVALID_ARGUMENT;
	}
	else
	{
		result = (matrix_t*)malloc(sizeof(matrix_t));
		if (result != NULL)
		{
			int* elements = (int*)malloc(rows * columns * sizeof(int));
			if (elements != NULL)
			{
				result->rows = rows;
				result->columns = columns;
				result->data = elements;
				for (int i = 0; i < rows * columns; i++)
				{
					*elements = *(dataptr + i);
					elements++;
				}
			}
			else
			{
				free(result);
				result = NULL;
				status = MATRIX_STATUS_ERROR_INSUFFICIENT_MEMORY;
			}
		}
		else
		{
			status = MATRIX_STATUS_ERROR_INSUFFICIENT_MEMORY;
		}
	}
	if (NULL != error)
	{
		*error = status;
	}
	return result;
}

status_t matrix_delete(matrix_t* mat) {
	status_t status = MATRIX_STATUS_OK;
	if (mat != NULL && mat->data != NULL)
	{
		free(mat->data);
		free(mat);
		return MATRIX_STATUS_OK;
	}
	else
	{
		status = MATRIX_STATUS_ERROR_INVALID_ARGUMENT;
	}
	return status;
}

int matrix_getRowCount(const matrix_t* mat) {
	status_t status = MATRIX_STATUS_OK;
	if (mat != NULL && mat->data != NULL)
	{
		return mat->rows;
	}
	else
	{
		return MATRIX_STATUS_ERROR_INVALID_ARGUMENT;
	}
}

int matrix_getColumnCount(const matrix_t* mat) {
	status_t status = MATRIX_STATUS_OK;
	if (mat != NULL && mat->data != NULL)
	{
		return mat->columns;
	}
	else
	{
		return MATRIX_STATUS_ERROR_INVALID_ARGUMENT;
	}
}

void matrix_getData(const matrix_t* mat) {
	if (mat != NULL && mat->data != NULL)
	{
		int rows = mat->rows;
		int columns = mat->columns;
		int* data1 = mat->data;
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < columns; j++) {
				printf(" %d ", *data1);
				data1++;
			}
			printf("\n");
		}
		printf("\n");
	}
	else
	{
		return MATRIX_STATUS_ERROR_INVALID_ARGUMENT;
	}
}

bool matrix_IsSquare(const matrix_t* mat)
{
	if (mat != NULL && mat->data != NULL)
	{
		int rows = mat->rows;
		int columns = mat->columns;
		if (rows == columns)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else
	{
		return MATRIX_STATUS_ERROR_INVALID_ARGUMENT;
	}
}