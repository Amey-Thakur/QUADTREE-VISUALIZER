#ifndef _MATRIX_API_INCLUDE_MATRIX_API_H_
#define _MATRIX_API_INCLUDE_MATRIX_API_H_

#include <types.h>
#include <stdbool.h>

#ifdef _cplusplus
extern "C" {
#endif // !_cplusplus

	// Function for creating an instance of matrix_t
	// rows and columns must be positive; if not, error is set to MATRIX_STATUS_ERROR_INVALID_ARGUMENT
	// If internal memory allocation fails error is set to MATRIX_STATUS_ERROR_INSUFFICIENT_MEMORY
	matrix_t* matrix_new(int rows, int columns, int* data, status_t* error);

	// Function for deleting an instance of matrix_t
	// If matrix was null or invalid returns MATRIX_STATUS_ERROR_INVALID_ARGUMENT
	status_t matrix_delete(matrix_t* mat);

	// Function to get the row count
	// If mat was null or invalid returns MATRIX_STATUS_ERROR_INVALID_ARGUMENT
	int matrix_getRowCount(const matrix_t* mat);

	// Function to get the column count
	// If mat was null or invalid returns MATRIX_STATUS_ERROR_INVALID_ARGUMENT
	int matrix_getColumnCount(const matrix_t* mat);

	// Function to print the matrix
	// If mat was null or invalid returns MATRIX_STATUS_ERROR_INVALID_ARGUMENT
	void matrix_getData(const matrix_t* mat);

	// Function to check if the given matrix is Square
	// If mat was null or invalid returns MATRIX_STATUS_ERROR_INVALID_ARGUMENT
	bool matrix_IsSquare(const matrix_t* mat);

#ifdef _cplusplus
}
#endif // !_cplusplus

#endif // !_MATRIX_API_INCLUDE_MATRIX_API_H_