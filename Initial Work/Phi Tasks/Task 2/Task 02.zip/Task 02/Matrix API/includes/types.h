#ifndef _MATRIX_API_INCLUDE_MATRIX_TYPES_H_
#define _MATRIX_API_INCLUDE_MATRIX_TYPES_H_

#include <stdint.h>

#ifdef _cplusplus
extern "C" {
#endif // !_cplusplus

	typedef struct matrix matrix_t;
	typedef int32_t status_t;

#ifdef _cplusplus
}
#endif // !_cplusplus
#endif // !_MATRIX_API_INCLUDE_MATRIX_TYPES_H_