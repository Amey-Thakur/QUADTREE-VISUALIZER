#include<stdio.h>
#include<conio.h>
void main()
{
 float area, base, height;
 clrscr();
 printf("Enter base \n");
 scanf("%f", &base);
 printf("Enter height \n");
 scanf("%f", &height);
 area=0.5*base*height;
 printf("Area of triangle = %f", area);
 getch();.

}